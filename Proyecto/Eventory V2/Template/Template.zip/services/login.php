<?php
  $host_name = 'localhost';
  $user_name = 'root';
  $password  = 'root';
  $data_base = 'eventory';
 ?>
